const express = require("express");
const {
  auth_callback,
  uninstall,
  load,
} = require("../controllers/shopController");

const router = express.Router();

router.get("/oauth", auth_callback);
router.get("/load", load);
router.get("/uninstall", uninstall);

module.exports = router;
