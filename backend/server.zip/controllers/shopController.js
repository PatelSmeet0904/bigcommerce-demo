const { authorize } = require("../helper/OAuthHelper");
const jwt = require("jsonwebtoken");
const axios = require("axios");
const db = require("../config/db.js");
const Shop = db.shops;

// @desc    Redirect to App
// @route   GET /api/bigcommerce/oauth
// @access  Public
const auth_callback = async (req, res) => {
  const { context, scope, code } = req.query;
  console.log("auth");
  console.log(context, scope, code);

  try {
    const appData = await authorize(req.query);
    console.log(appData);

    if (appData) {
      const options = {
        method: "GET",
        url: `${process.env.API_PATH}/v2/store`,
        headers: {
          "X-Auth-Token": appData.access_token,
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      };
      console.log(options);
      const { data } = await axios(options);
      console.log(data);

      const [dbShop, created] = await Shop.upsert({
        id: data.id,
        access_token: appData.access_token,
        scope: appData.scope,
        context: appData.context,
        account_uuid: data.account_uuid,
        domain: data.domain,
        secure_url: data.secure_url,
        status: data.status,
        shopName: data.name,
        phone: data.phone,
        admin_email: data.admin_email,
        first_name: data.first_name,
        last_name: data.last_name,
        country_code: data.country_code,
        timezone: data.timezone.name,
        currency: data.currency,
        plan_name: data.plan_name,
      });
      console.log("yes", created);
      return res.json({ type: "oauth", data: appData });
    }
  } catch (error) {
    // console.log(error);
    res.status(400).json({ Message: error.message });
  }
};

// @desc    Redirect to App
// @route   GET /api/bigcommerce/load
// @access  Public
const load = async (req, res) => {
  const { signed_payload_jwt } = req.query;
  console.log("load");
  const decodedPayload = jwt.decode(signed_payload_jwt);
  console.log(decodedPayload);
  return res.json({ type: "load", info: decodedPayload });
};

// @desc    Redirect to App
// @route   GET /api/bigcommerce/uninstall
// @access  Public
const uninstall = async (req, res) => {
  const { signed_payload_jwt } = req.query;
  console.log("uninstall");
  const decodedPayload = jwt.decode(signed_payload_jwt);
  console.log(decodedPayload);
  return res.json({ Message: "Uninstall" });
};

module.exports = { auth_callback, load, uninstall };
