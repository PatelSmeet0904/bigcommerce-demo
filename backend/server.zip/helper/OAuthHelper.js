const BigCommerce = require("node-bigcommerce");

const authorize = async (query) => {
  try {
    const url = "https://login.bigcommerce.com/oauth2/token";
    const config = {
      grant_type: "authorization_code",
      client_id: `${process.env.CLIENT_ID}`,
      client_secret: `${process.env.CLIENT_SECRET}`,
      redirect_uri: `${process.env.redirect_uri}`,
      context: context,
      code: code,
      scope: scope,
    };
    const bigCommerce = new BigCommerce({
      clientId: `${process.env.CLIENT_ID}`,
      secret: `${process.env.CLIENT_SECRET}`,
      callback: `${process.env.redirect_uri}`,
      responseType: "json",
    });
    const response = await bigCommerce.authorize(query);
    console.log(response);
    return response.data;
  } catch (error) {
    console.log(error);
  }
};

module.exports = { authorize };
